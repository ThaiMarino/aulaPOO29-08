package aula2908;

public class DiaDosNamorados extends CartaoWeb {


	public DiaDosNamorados(String destinatario) {
		super(destinatario);
		// TODO Auto-generated constructor stub
	}

	public String message(String destinatario){
		return("Feliz dia dos Namorados "+destinatario);
	}



}

