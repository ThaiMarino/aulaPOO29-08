package aula2908;

public abstract class CartaoWeb {
	protected String destinatario;
	
	
	public CartaoWeb(String destinatario) {
		this.destinatario = destinatario;
	}

	public abstract String message(String destinatario);



	public String getDestinatario() {
		return destinatario;
	}

	public void setDestinatario(String destinatario) {
		this.destinatario = destinatario;
	}

	

	@Override
	public String toString() {
		return "CartaoWeb [destinatario=" + destinatario + "]";
	}
}
