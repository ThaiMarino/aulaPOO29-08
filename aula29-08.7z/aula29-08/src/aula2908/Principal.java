package aula2908;


public class Principal {
	
	public static void main(String[] args) {
		CartaoWeb cartoes[] = new CartaoWeb[3];
		
		cartoes[0] = new Natal("João");
		cartoes[1] = new Aniversario("Emyle");
		cartoes[3] = new DiaDosNamorados("Pedro");
		
		for(CartaoWeb cartao: cartoes) {
			System.out.println(cartao.message(null));
		}
	}
}
