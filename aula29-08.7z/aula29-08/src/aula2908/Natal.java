package aula2908;

public class Natal extends CartaoWeb {

	
	public Natal(String destinatario) {
		super(destinatario);
	}
	
	public String message (String destinatario) {
		return("Feliz Natal "+destinatario);
	}


}
