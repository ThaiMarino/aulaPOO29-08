package aula2908;

public class Aniversario extends CartaoWeb {

	public Aniversario(String destinatario) {
		super(destinatario);
		// TODO Auto-generated constructor stub
	}

	public String message (String destinatario) {
		return("Feliz Aniversário! "+destinatario);
	}

}